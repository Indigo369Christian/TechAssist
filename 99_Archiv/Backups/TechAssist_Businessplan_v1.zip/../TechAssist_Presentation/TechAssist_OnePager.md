---
title: "TechAssist – One-Pager (Deutsch)"
subtitle: "KI-gestützter Digital-Assistent für inklusive Teilhabe"
author: "Christian Kersten"
date: "September 2025"
geometry: a4paper
fontsize: 12pt
---

# TechAssist – Überblick (1 Seite)

## Zweck und Ziel
TechAssist ermöglicht einen einfachen, sicheren und begleiteten Zugang zur digitalen Welt – insbesondere für Menschen mit geringen Technikkenntnissen und für Institutionen mit Inklusionsauftrag (Jobcenter, Kommunen, Sozialträger, Bildung).

## Problemstellung
- Digitale Überforderung, Misstrauen, fragmentierte Kosten (Apps/Cloud/Abos).
- Fehlende durchgängige Begleitung: Einrichtung, Lernen, Datenschutz, Support sind getrennt.
- Institutionen benötigen skalierbare, DSGVO-konforme Lösungen mit Reporting.

## Lösung (Kernleistungen)
- **Assistent mit Ausführung:** „Erklären → Bestätigen → Ausführen“ (Setup, Berechtigungen, Routinen).
- **Lernmodus:** Schritt-für-Schritt-Anleitung (Sprache/Text), Fortschrittsspeicher.
- **Datenschutz-Coach:** Berechtigungs-Hygiene, Hinweise, Berichte, Remediation.
- **Support:** Remote-Hilfe, Playbooks, SLA-fähig.
- **Plattform:** Alles in einer Anwendung, Rollen/Rechte für Institutionen.

## Zielgruppen & Nutzen
- **Bürger/Senioren:** Selbstständigkeit, Sicherheit, verständliche Begleitung.
- **Jobcenter/Kommunen/Träger:** Skalierbare Inklusion, Reporting, Compliance, Kostenkontrolle.
- **KMU/Bildung:** Zeitersparnis, Automatisierung, weniger Supportaufwand.

## Geschäftsmodell (Kurz)
- **B2C:** Freemium → Premium (4,99 €/Mon), Sozialtarif (1,99 €/Mon).
- **B2B/B2G:** Lizenzen (10–25 T€/Jahr) inkl. Admin, Rollen, Reporting, SLA.
- Zusatz: Schulungen, Audits, White-Label/OEM-Vorinstallationen.

## Wirkung & Kennzahlen (Beispiele)
- **Nutzer gesamt (Y1–Y3):** 10k → 50k → 100k  
- **Umsatz (Y1–Y3):** ~90k€ → ~500k€ → >1,0 Mio. €  
- **Break-Even:** ~3.000 zahlende Nutzer (ca.180k€ ARR), erwartet Monat 16–20.

## Risiken & Gegenmaßnahmen (Auszug)
| Risiko | Auswirkung | Gegenmaßnahme |
|---|---|---|
| Datenschutz/DSGVO | Bußgelder/Vertrauen | Privacy-by-Design, externe Audits |
| OS-Restriktionen | Funktionsgrenzen | Fallback-Flows, Accessibility/MDM-APIs |
| Akzeptanz (KI) | Zurückhaltung | Transparenz, Undo, einfache Sprache |

## Status
**Projektstart:** 01.11.2025 • **Rechtsform/Sitz:** in Gründung/noch offen  
**Kontakt:** Christian Kersten
